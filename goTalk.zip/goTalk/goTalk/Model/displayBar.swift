//
//  displayBar.swift
//  test
//
//  Created by Yagnik Vadher on 11/3/17.
//  Copyright © 2017 ksd8. All rights reserved.
//

import Foundation

class displayBar {
    var clickedPhotos: [String] = []
}
