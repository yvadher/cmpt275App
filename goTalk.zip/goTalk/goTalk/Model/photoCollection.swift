//
//  photoCollection.swift
//  test
//
//  Created by Yagnik Vadher on 11/2/17.
//  Copyright © 2017 ksd8. All rights reserved.
//

import Foundation

struct PhotoCategory {
    var categoryName: String
    var title: String
    var imageNames: [String]
    
    static func fetchPhotos() -> [PhotoCategory] {
        var categories = [PhotoCategory]()
        let photosData = PhotosLibrary.downloadPhotosData()
   
        for i in 0...(photosData.count-1) {
            let categoryImageName = photosData[i].caetegoryName
            if let imageNames = photosData[i].imagesNames as? [String] {
                let newCategory = PhotoCategory(categoryName: categoryImageName, title: categoryImageName, imageNames: imageNames)
                categories.append(newCategory)
            }
        }
        return categories
    }
}

class PhotosLibrary
{
    struct categoryUnit{
        let caetegoryName: String
        let imagesNames : [String]
    }
    class func downloadPhotosData() -> [categoryUnit]
    {
        let object = [
            categoryUnit(caetegoryName: "General", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "General")),
            categoryUnit(caetegoryName: "Feelings", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Feelings")),
            categoryUnit(caetegoryName: "Colors", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Colors")),
            categoryUnit(caetegoryName: "Drinks", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Drinks")),
            categoryUnit(caetegoryName: "Food", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Food")),
            categoryUnit(caetegoryName: "Places", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Places")),
            categoryUnit(caetegoryName: "Toys", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Toys")),
            categoryUnit(caetegoryName: "Numbers", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Numbers")),
            categoryUnit(caetegoryName: "Letters", imagesNames: PhotosLibrary.generateImage(categoryPrefix: "Letters")),
        ]
        
        
        //print (object)
        return object
    }
    
    private class func generateImage(categoryPrefix: String) -> [String] {
        var imageNames = [String]()
        
        switch categoryPrefix {
        case "General":
            imageNames = ["I", "No", "Okay", "See", "Sleep", "What", "Yes", "You", "Dislike", "Hear", "Like"]
            
        case "Feelings":
            imageNames = ["Afraid", "Angry", "Confused", "Happy", "Nervous", "Sad", "Shy", "Sick", "Surprised", "Tired"]
            
        case "Colors":
            imageNames = ["Black", "Blue", "Brown", "Green", "Grey", "Orange", "Pink", "Purple", "Red"]
            
        case "Food":
            imageNames = ["Apple", "Banana", "Bread", "Breakfast", "Burger", "Butter", "Cereal", "Chocolate", "Grapes", "IceCream", "Noodles", "Pizza", "Sandwich", "Eat"]
            
        case "Drinks":
            imageNames = ["Juice", "Lemonade", "Milk", "Soda", "Water"]
            
        case "Places":
            imageNames = ["Home", "School", "Clinic", "Store", "Bedroom", "Bathroom", "Kitchen", "Playground"]
            
        case "Toys":
            imageNames = ["Ball", "Book", "Car", "Pencils", "Lego", "Swing", "Play"]
            
        case "Numbers":
            imageNames = ["Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One", "Zero"]
        
        case "Letters":
            imageNames = ["A", "B", "C", "D", "E", "F", "G", "H", "I (Letter)", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
            
        default:
            imageNames = []
        }

        
        return imageNames
    }
}








